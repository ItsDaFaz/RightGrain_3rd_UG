<?php
$district = ($_POST['district']);
$season = ($_POST['season']);
$landAmount  = ($_POST['landAmount']);

$user = 'root';
$pass = '';
$db = 'findrightcrop2';

$db_connect = new mysqli('localhost',$user,$pass,$db) or die('unable to connect');
echo 'Done connecting Database'."<br><br>\n\n";

$qry1 = "select district.DistrictName, crop.CropName, 
        (crop.ProductionPerAcre*$landAmount*crop.SellingPricePerKilo 
        - crop.ProductionPerAcre*$landAmount*districtwise.EstimateCostPerKilo) as profit, 
        crop.TimeToHarvest as FirstHarvest from district NATURAL JOIN districtwise 
        NATURAL JOIN crop NATURAL JOIN seasonwise NATURAL JOIN season 
        WHERE district.DistrictName = '$district' AND season.SeasonName = '$season' 
        order by profit DESC";

$res1 = $db_connect->query($qry1) or die('bad query 1');
echo  "DistrictName"."----------"."CropName"."----------"."First Harvest"."-----"."Profit"."<br>"."<br>";


while($row1 = $res1->fetch_assoc()){
    echo  $row1["DistrictName"]."--------------".$row1["CropName"]."------------- ". $row1["FirstHarvest"]." Months ---------". $row1["profit"]." Taka"."<br>";
}







