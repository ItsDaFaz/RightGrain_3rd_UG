<html>
<body>

<form action = "searchCropCode.php" method = "post" >

    <!-- station Id: <input type = "text" name = "stationId"/>
    station Name: <input type = "text" name = "stationName"/>
    longitude: <input type = "text" name = "longitude"/>
    latitude: <input type = "text" name = "latitude"/>
    Show: <input type = "submit"/>  -->

    District: <input type = "text" name = "district"/>
    Season : <input type = "text" name = "season"/>
    Land Amount : <input type = "int(11)" name = "landAmount"/>
    <input type = "submit" value = "OK"/>


</form>

</body>
</html>


